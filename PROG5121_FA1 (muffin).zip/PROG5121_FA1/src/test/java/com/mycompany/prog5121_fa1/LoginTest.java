package com.mycompany.prog5121_fa1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    @Test
    public void testUserName_Invalid_NoUnderscore() {
        Login login = new Login();
        assertFalse(login.checkUserName("kyle"));
    }

    @Test
    public void testCell_Valid_Plus27() {
        Login login = new Login();
        assertTrue(login.checkCellPhoneNumber("+27718693002"));
    }

    @Test
    public void testCell_Invalid_NoPlus() {
        Login login = new Login();
        assertFalse(login.checkCellPhoneNumber("08575975889"));
    }

    @Test
    public void testCell_Invalid_TooLong() {
        Login login = new Login();
        assertFalse(login.checkCellPhoneNumber("+27718693002123"));
    }

    @Test
    public void testPassword_Valid() {
        Login login = new Login();
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testPassword_Invalid_NoSpecial() {
        Login login = new Login();
        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testRegister_Success() {
        Login login = new Login();
        String result = login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27718693002", "Kyle", "Smith");
        assertEquals("User registered successfully.", result);
    }

    @Test
    public void testLogin_Success() {
        Login login = new Login();
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27718693002", "Kyle", "Smith");
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLogin_Fail() {
        Login login = new Login();
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27718693002", "Kyle", "Smith");
        assertFalse(login.loginUser("kyl_1", "wrong"));
    }
}