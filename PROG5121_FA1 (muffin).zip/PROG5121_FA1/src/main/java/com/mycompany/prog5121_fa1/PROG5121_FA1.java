package com.mycompany.prog5121_fa1;

import java.util.Scanner;

public class PROG5121_FA1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login loginObj = new Login();
        Message helper = new Message();

        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter Username: ");
        String username = scanner.nextLine();

        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        System.out.print("Enter Cell Number: ");
        String cell = scanner.nextLine();

        String regResult = loginObj.registerUser(username, password, cell, firstName, lastName);
        System.out.println(regResult);

        System.out.print("Enter Username to Login: ");
        String loginUser = scanner.nextLine();

        System.out.print("Enter Password to Login: ");
        String loginPass = scanner.nextLine();

        if (!loginObj.loginUser(loginUser, loginPass)) {
            System.out.println("Login failed.");
            scanner.close();
            return;
        }

        System.out.println(loginObj.returnLoginStatus(loginUser, loginPass));
        System.out.println("Welcome to QuickChat");

        int numMessages = 2;
        int sent = 0;

        for (int i = 0; i < numMessages; i++) {
            System.out.println("Message " + (i + 1));
            System.out.print("Enter recipient number: ");
            String recipient = scanner.nextLine();
            String recCheck = helper.checkRecipientCell(recipient);
            System.out.println(recCheck);
            if (!recCheck.equals("Cell phone number successfully captured.")) {
                i--;
                continue;
            }
            System.out.print("Enter message: ");
            String messageText = scanner.nextLine();
            String lenCheck = helper.checkMessageLength(messageText);
            System.out.println(lenCheck);
            if (!lenCheck.equals("Message ready to send.")) {
                i--;
                continue;
            }
            Message newMessage = new Message(recipient, messageText, sent);
            System.out.println(newMessage.MessageIDGenerated());
            System.out.println("Message Hash: " + newMessage.createMessageHash());
            System.out.println("1 - Send Message");
            System.out.println("2 - Disregard Message");
            System.out.println("3 - Store Message");
            System.out.print("Choose: ");
            int choice = Integer.parseInt(scanner.nextLine());
            String result = newMessage.SentMessage(choice);
            System.out.println(result);
            if (choice == 1) {
                System.out.println("Full Details:");
                System.out.println("MessageID: " + newMessage.getMessageId());
                System.out.println("Message Hash: " + newMessage.createMessageHash());
                System.out.println("Recipient: " + newMessage.getRecipient());
                System.out.println("Message: " + newMessage.getContent());
                sent++;
            }
            System.out.println("Total sent: " + newMessage.returnTotalMessagess());
        }
        scanner.close();
    }
}